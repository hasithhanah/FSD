/**
 * MarkMirror: ResultRadar Rush
 * Static Single Page Application (ES6+)
 * Embedded 25-student dataset, credit-weighted SGPA/CGPA engine,
 * pre-computed batch analytics, Chart.js visualizations, and A4 print support.
 */

// 1. Standardized Grade-to-Point Lookup Map
const GRADE_POINTS = Object.freeze({
  O: 10,
  "A+": 9,
  A: 8,
  "B+": 7,
  B: 6,
  C: 5,
  P: 4,
  F: 0,
});

// 2. Canonical Subject Metadata (Total = 20 Semester Credits)
const SUBJECT_CATALOG = Object.freeze([
  { key: "math", code: "MA301", name: "Mathematics", credits: 4 },
  { key: "dbms", code: "CS302", name: "DBMS", credits: 4 },
  { key: "os", code: "CS303", name: "Operating Systems", credits: 4 },
  { key: "cn", code: "CS304", name: "Computer Networks", credits: 3 },
  { key: "se", code: "CS305", name: "Software Engineering", credits: 3 },
  { key: "ailab", code: "CS306", name: "AI Lab", credits: 2 },
]);

const BRANCH_FULL_NAMES = Object.freeze({
  CSE: "B.Tech. Computer Science & Engineering",
  ECE: "B.Tech. Electronics & Communication Engineering",
});

// 3. Simulated Embedded JSON Dataset (25 Realistic Engineering Students)
// Operating Systems pass rate = 17 / 25 = 68.0% (strictly lowest among all 6 subjects).
// Hall Ticket 22CSE104 is calibrated to SGPA = 8.85 (177 / 20) with Distinction.
const RAW_STUDENT_DATASET = [
  // --- CSE BRANCH (15 Students) ---
  {
    hallTicket: "22CSE101",
    name: "Ananya Krishnan",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 744.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 38, external: 56, grade: "O" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 37, external: 55, grade: "O" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 36, external: 54, grade: "O" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 37, external: 53, grade: "O" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 35, external: 51, grade: "A+" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 39, external: 56, grade: "O" },
    ],
  },
  {
    hallTicket: "22CSE102",
    name: "Vikramaditya Rao",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 728.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 36, external: 55, grade: "O" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 36, external: 54, grade: "O" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 34, external: 51, grade: "A+" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 35, external: 55, grade: "O" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 34, external: 50, grade: "A+" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 38, external: 54, grade: "O" },
    ],
  },
  {
    hallTicket: "22CSE103",
    name: "Meera Nair",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 716.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 35, external: 52, grade: "A+" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 38, external: 53, grade: "O" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 33, external: 49, grade: "A+" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 35, external: 51, grade: "A+" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 36, external: 54, grade: "O" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 37, external: 53, grade: "O" },
    ],
  },
  {
    hallTicket: "22CSE104",
    name: "Rohan Deshmukh",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 696.5,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 38, external: 54, grade: "O" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 35, external: 50, grade: "A+" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 32, external: 44, grade: "A" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 36, external: 48, grade: "A+" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 31, external: 46, grade: "A" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 37, external: 51, grade: "A+" },
    ],
  },
  {
    hallTicket: "22CSE105",
    name: "Siddharth Verma",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 688.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 34, external: 51, grade: "A+" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 33, external: 49, grade: "A+" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 30, external: 44, grade: "A" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 34, external: 48, grade: "A+" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 35, external: 50, grade: "A+" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 36, external: 50, grade: "A+" },
    ],
  },
  {
    hallTicket: "22CSE106",
    name: "Divya Menon",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 672.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 33, external: 49, grade: "A+" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 32, external: 46, grade: "A" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 29, external: 43, grade: "A" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 33, external: 47, grade: "A+" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 32, external: 45, grade: "A" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 37, external: 54, grade: "O" },
    ],
  },
  {
    hallTicket: "22CSE107",
    name: "Karthik Subramanian",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 656.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 31, external: 44, grade: "A" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 32, external: 48, grade: "A+" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 28, external: 40, grade: "B+" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 30, external: 43, grade: "A" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 31, external: 45, grade: "A" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 35, external: 48, grade: "A+" },
    ],
  },
  {
    hallTicket: "22CSE108",
    name: "Neha Kulkarni",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 584.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 30, external: 42, grade: "A" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 29, external: 39, grade: "B+" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 18, external: 17, grade: "F" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 19, external: 16, grade: "F" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 28, external: 41, grade: "B+" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 34, external: 46, grade: "A+" },
    ],
  },
  {
    hallTicket: "22CSE109",
    name: "Arjun Malhotra",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 632.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 30, external: 41, grade: "A" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 31, external: 43, grade: "A" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 26, external: 38, grade: "B+" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 28, external: 39, grade: "B+" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 31, external: 44, grade: "A" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 34, external: 47, grade: "A+" },
    ],
  },
  {
    hallTicket: "22CSE110",
    name: "Pooja Reddy",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 608.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 29, external: 39, grade: "B+" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 28, external: 42, grade: "A" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 25, external: 36, grade: "B+" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 27, external: 37, grade: "B+" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 29, external: 42, grade: "A" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 32, external: 43, grade: "A" },
    ],
  },
  {
    hallTicket: "22CSE111",
    name: "Rahul Chatterjee",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 536.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 26, external: 35, grade: "B+" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 16, external: 18, grade: "F" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 17, external: 16, grade: "F" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 25, external: 33, grade: "B" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 27, external: 35, grade: "B+" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 31, external: 41, grade: "A" },
    ],
  },
  {
    hallTicket: "22CSE112",
    name: "Sneha Iyer",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 580.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 27, external: 34, grade: "B+" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 25, external: 33, grade: "B" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 22, external: 29, grade: "B" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 26, external: 34, grade: "B+" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 28, external: 36, grade: "B+" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 31, external: 42, grade: "A" },
    ],
  },
  {
    hallTicket: "22CSE113",
    name: "Manish Tiwari",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 492.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 17, external: 18, grade: "F" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 24, external: 31, grade: "B" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 15, external: 17, grade: "F" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 23, external: 29, grade: "B" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 16, external: 19, grade: "F" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 29, external: 37, grade: "B+" },
    ],
  },
  {
    hallTicket: "22CSE114",
    name: "Kavya Joshi",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 560.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 25, external: 32, grade: "B" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 24, external: 30, grade: "B" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 21, external: 26, grade: "C" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 25, external: 31, grade: "B" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 26, external: 35, grade: "B+" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 30, external: 38, grade: "B+" },
    ],
  },
  {
    hallTicket: "22CSE115",
    name: "Devansh Patel",
    branch: "CSE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 468.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 22, external: 25, grade: "C" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 18, external: 15, grade: "F" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 16, external: 15, grade: "F" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 17, external: 18, grade: "F" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 23, external: 29, grade: "B" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 28, external: 35, grade: "B+" },
    ],
  },

  // --- ECE BRANCH (10 Students) ---
  {
    hallTicket: "22ECE201",
    name: "Ishita Banerjee",
    branch: "ECE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 736.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 38, external: 55, grade: "O" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 36, external: 54, grade: "O" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 35, external: 51, grade: "A+" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 37, external: 54, grade: "O" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 36, external: 54, grade: "O" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 38, external: 53, grade: "O" },
    ],
  },
  {
    hallTicket: "22ECE202",
    name: "Pranav Kulkarni",
    branch: "ECE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 684.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 35, external: 52, grade: "A+" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 34, external: 50, grade: "A+" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 32, external: 46, grade: "A" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 36, external: 54, grade: "O" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 33, external: 49, grade: "A+" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 36, external: 50, grade: "A+" },
    ],
  },
  {
    hallTicket: "22ECE203",
    name: "Tanvi Deshpande",
    branch: "ECE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 660.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 34, external: 49, grade: "A+" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 31, external: 45, grade: "A" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 30, external: 43, grade: "A" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 33, external: 48, grade: "A+" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 32, external: 47, grade: "A" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 37, external: 53, grade: "O" },
    ],
  },
  {
    hallTicket: "22ECE204",
    name: "Aditya Nambiar",
    branch: "ECE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 572.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 29, external: 39, grade: "B+" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 16, external: 19, grade: "F" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 18, external: 17, grade: "F" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 28, external: 37, grade: "B+" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 30, external: 41, grade: "A" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 34, external: 47, grade: "A+" },
    ],
  },
  {
    hallTicket: "22ECE205",
    name: "Riya Sengupta",
    branch: "ECE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 624.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 31, external: 44, grade: "A" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 29, external: 42, grade: "A" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 27, external: 39, grade: "B+" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 30, external: 42, grade: "A" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 31, external: 45, grade: "A" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 35, external: 48, grade: "A+" },
    ],
  },
  {
    hallTicket: "22ECE206",
    name: "Harshvardhan Singh",
    branch: "ECE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 504.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 15, external: 19, grade: "F" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 25, external: 34, grade: "B" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 17, external: 16, grade: "F" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 18, external: 17, grade: "F" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 26, external: 37, grade: "B+" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 30, external: 41, grade: "A" },
    ],
  },
  {
    hallTicket: "22ECE207",
    name: "Shruti Agarwal",
    branch: "ECE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 596.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 28, external: 40, grade: "B+" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 27, external: 39, grade: "B+" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 25, external: 36, grade: "B+" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 29, external: 42, grade: "A" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 28, external: 39, grade: "B+" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 33, external: 46, grade: "A" },
    ],
  },
  {
    hallTicket: "22ECE208",
    name: "Nikhil Choudhary",
    branch: "ECE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 552.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 26, external: 37, grade: "B+" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 25, external: 35, grade: "B+" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 22, external: 29, grade: "B" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 16, external: 19, grade: "F" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 27, external: 36, grade: "B+" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 31, external: 42, grade: "A" },
    ],
  },
  {
    hallTicket: "22ECE209",
    name: "Aishwarya Hegde",
    branch: "ECE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 520.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 24, external: 31, grade: "B" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 17, external: 18, grade: "F" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 16, external: 18, grade: "F" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 25, external: 33, grade: "B" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 24, external: 30, grade: "B" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 29, external: 39, grade: "B+" },
    ],
  },
  {
    hallTicket: "22ECE210",
    name: "Varun Saxena",
    branch: "ECE",
    semester: "V Semester",
    batch: "2022–2026",
    previousCredits: 80,
    previousWeightedPoints: 448.0,
    subjects: [
      { code: "MA301", name: "Mathematics", credits: 4, internal: 16, external: 16, grade: "F" },
      { code: "CS302", name: "DBMS", credits: 4, internal: 21, external: 25, grade: "C" },
      { code: "CS303", name: "Operating Systems", credits: 4, internal: 14, external: 15, grade: "F" },
      { code: "CS304", name: "Computer Networks", credits: 3, internal: 15, external: 17, grade: "F" },
      { code: "CS305", name: "Software Engineering", credits: 3, internal: 17, external: 18, grade: "F" },
      { code: "CS306", name: "AI Lab", credits: 2, internal: 18, external: 18, grade: "F" },
    ],
  },
];

// 4. SGPA & CGPA Calculation Engine
function computeStudentRecord(rawStudent) {
  let semesterRegisteredCredits = 0;
  let semesterEarnedCredits = 0;
  let semesterWeightedPoints = 0;
  let backlogCount = 0;
  let totalMarksSum = 0;

  const enrichedSubjects = rawStudent.subjects.map((sub) => {
    const gradePoint = GRADE_POINTS[sub.grade] ?? 0;
    const totalMarks = sub.internal + sub.external;
    const passed = sub.grade !== "F" && gradePoint > 0;
    const creditPoints = sub.credits * gradePoint;

    semesterRegisteredCredits += sub.credits;
    semesterWeightedPoints += creditPoints;
    totalMarksSum += totalMarks;

    if (passed) {
      semesterEarnedCredits += sub.credits;
    } else {
      backlogCount += 1;
    }

    return {
      ...sub,
      totalMarks,
      gradePoint,
      creditPoints,
      passed,
    };
  });

  // Official Credit-Weighted Formula: sum(Credits * GradePoints) / sum(Credits)
  const sgpa =
    semesterRegisteredCredits > 0
      ? Number((semesterWeightedPoints / semesterRegisteredCredits).toFixed(2))
      : 0;

  const totalCumulativeCredits =
    rawStudent.previousCredits + semesterRegisteredCredits;
  const totalCumulativeWeightedPoints =
    rawStudent.previousWeightedPoints + semesterWeightedPoints;

  const cgpa =
    totalCumulativeCredits > 0
      ? Number(
          (totalCumulativeWeightedPoints / totalCumulativeCredits).toFixed(2)
        )
      : sgpa;

  let classification = "Promoted (With Backlog)";
  if (backlogCount === 0) {
    if (sgpa >= 7.5) {
      classification = "First Class with Distinction";
    } else if (sgpa >= 6.0) {
      classification = "First Class";
    } else if (sgpa >= 5.0) {
      classification = "Second Class";
    } else {
      classification = "Pass Class";
    }
  }

  return {
    ...rawStudent,
    subjects: enrichedSubjects,
    semesterRegisteredCredits,
    semesterEarnedCredits,
    semesterWeightedPoints,
    totalMarksSum,
    backlogCount,
    sgpa,
    cgpa,
    classification,
    passedAll: backlogCount === 0,
  };
}

// 5. Pre-Computation Engine for Batch Summary Statistics (Runs once on load)
function precomputeBatchAnalytics(students) {
  const totalStudents = students.length;
  const branchCounts = { CSE: 0, ECE: 0 };

  let allClearCount = 0;
  let distinctionCount = 0;
  let cgpaSum = 0;

  // Initialize subject accumulators
  const subjectAccumulators = SUBJECT_CATALOG.map((meta) => ({
    code: meta.code,
    name: meta.name,
    credits: meta.credits,
    passCount: 0,
    failCount: 0,
    totalCount: 0,
  }));

  // CGPA histogram buckets
  const cgpaBins = [
    { label: "< 6.00", min: 0, max: 5.999, count: 0 },
    { label: "6.00 – 6.99", min: 6.0, max: 6.999, count: 0 },
    { label: "7.00 – 7.99", min: 7.0, max: 7.999, count: 0 },
    { label: "8.00 – 8.99", min: 8.0, max: 8.999, count: 0 },
    { label: "9.00 – 10.00", min: 9.0, max: 10.01, count: 0 },
  ];

  students.forEach((student) => {
    branchCounts[student.branch] = (branchCounts[student.branch] || 0) + 1;

    if (student.passedAll) {
      allClearCount += 1;
    }
    if (student.classification === "First Class with Distinction") {
      distinctionCount += 1;
    }
    cgpaSum += student.cgpa;

    // Tally subject pass/fail
    student.subjects.forEach((sub, idx) => {
      const acc = subjectAccumulators[idx];
      if (!acc) return;
      acc.totalCount += 1;
      if (sub.passed) {
        acc.passCount += 1;
      } else {
        acc.failCount += 1;
      }
    });

    // Tally CGPA bins
    const matchedBin = cgpaBins.find(
      (bin) => student.cgpa >= bin.min && student.cgpa <= bin.max
    );
    if (matchedBin) {
      matchedBin.count += 1;
    }
  });

  const subjectStats = subjectAccumulators.map((acc) => {
    const passRate =
      acc.totalCount > 0
        ? Number(((acc.passCount / acc.totalCount) * 100).toFixed(1))
        : 0;
    const failRate = Number((100 - passRate).toFixed(1));
    return {
      ...acc,
      passRate,
      failRate,
    };
  });

  const lowestPassSubject = subjectStats.reduce((lowest, current) =>
    current.passRate < lowest.passRate ? current : lowest
  );

  // Pre-sort Top 10 Leaderboards per branch (SGPA desc -> Earned Credits desc -> CGPA desc)
  const sortTopPerformers = (list) =>
    [...list]
      .sort((a, b) => {
        if (b.sgpa !== a.sgpa) return b.sgpa - a.sgpa;
        if (b.semesterEarnedCredits !== a.semesterEarnedCredits) {
          return b.semesterEarnedCredits - a.semesterEarnedCredits;
        }
        return b.cgpa - a.cgpa;
      })
      .slice(0, 10);

  const leaderboardsByBranch = {
    ALL: sortTopPerformers(students),
    CSE: sortTopPerformers(students.filter((s) => s.branch === "CSE")),
    ECE: sortTopPerformers(students.filter((s) => s.branch === "ECE")),
  };

  return {
    totalStudents,
    branchCounts,
    allClearCount,
    overallPassRate: Number(((allClearCount / totalStudents) * 100).toFixed(1)),
    meanCgpa: Number((cgpaSum / totalStudents).toFixed(2)),
    distinctionCount,
    subjectStats,
    lowestPassSubject,
    cgpaBins,
    leaderboardsByBranch,
  };
}

// 6. Application State
const PROCESSED_STUDENTS = RAW_STUDENT_DATASET.map(computeStudentRecord);
const STUDENT_INDEX = new Map(
  PROCESSED_STUDENTS.map((student) => [student.hallTicket.toUpperCase(), student])
);
const BATCH_ANALYTICS = precomputeBatchAnalytics(PROCESSED_STUDENTS);

const appState = {
  activeTab: "marksheet",
  selectedHallTicket: "22CSE104",
  leaderboardBranch: "ALL",
  chartsInitialized: false,
  passRateChartInstance: null,
  cgpaChartInstance: null,
};

// 7. DOM Element References
const dom = {
  tabButtons: document.querySelectorAll(".tab-btn"),
  panelMarksheet: document.getElementById("panel-marksheet"),
  panelAnalytics: document.getElementById("panel-analytics"),
  printBtn: document.getElementById("print-marksheet-btn"),

  lookupForm: document.getElementById("lookup-form"),
  searchInput: document.getElementById("hall-ticket-input"),
  clearSearchBtn: document.getElementById("clear-search-btn"),
  quickRosterButtons: document.getElementById("quick-roster-buttons"),
  emptyState: document.getElementById("lookup-empty-state"),
  emptyStateMsg: document.getElementById("empty-state-message"),
  resetDefaultBtn: document.getElementById("reset-default-student-btn"),
  resultContainer: document.getElementById("student-result-container"),

  kpiSgpa: document.getElementById("kpi-sgpa"),
  kpiSgpaMeta: document.getElementById("kpi-sgpa-meta"),
  kpiCgpa: document.getElementById("kpi-cgpa"),
  kpiCgpaMeta: document.getElementById("kpi-cgpa-meta"),
  kpiCredits: document.getElementById("kpi-credits"),
  kpiCreditsMeta: document.getElementById("kpi-credits-meta"),
  kpiStanding: document.getElementById("kpi-standing"),
  kpiStandingMeta: document.getElementById("kpi-standing-meta"),

  sheetHtno: document.getElementById("sheet-htno"),
  sheetName: document.getElementById("sheet-name"),
  sheetBranch: document.getElementById("sheet-branch"),
  sheetSemester: document.getElementById("sheet-semester"),
  sheetBatch: document.getElementById("sheet-batch"),
  sheetOverallStatus: document.getElementById("sheet-overall-status"),
  sheetSubjectsTbody: document.getElementById("sheet-subjects-tbody"),
  sheetSubjectsTfoot: document.getElementById("sheet-subjects-tfoot"),
  sheetFormulaLine: document.getElementById("sheet-formula-line"),
  sheetSgpa: document.getElementById("sheet-sgpa"),
  sheetCgpa: document.getElementById("sheet-cgpa"),
  sheetClassification: document.getElementById("sheet-classification"),

  batchTotalStudents: document.getElementById("batch-total-students"),
  batchBranchSplit: document.getElementById("batch-branch-split"),
  batchPassRate: document.getElementById("batch-pass-rate"),
  batchPassCount: document.getElementById("batch-pass-count"),
  batchMeanCgpa: document.getElementById("batch-mean-cgpa"),
  batchDistinctionCount: document.getElementById("batch-distinction-count"),
  batchLowestSubject: document.getElementById("batch-lowest-subject"),
  batchLowestSubjectMeta: document.getElementById("batch-lowest-subject-meta"),
  subjectRateSummary: document.getElementById("subject-rate-summary"),
  cgpaBinSummary: document.getElementById("cgpa-bin-summary"),

  branchFilterButtons: document.querySelectorAll(".branch-filter-btn"),
  leaderboardTbody: document.getElementById("leaderboard-tbody"),
};

// 8. Rendering: Individual Marksheet & KPI Summary
function renderQuickRoster() {
  const featuredTickets = [
    { htno: "22CSE104", note: "Distinction · 8.85" },
    { htno: "22CSE101", note: "CSE Topper" },
    { htno: "22ECE201", note: "ECE Topper" },
    { htno: "22CSE108", note: "Backlog Sample" },
  ];

  dom.quickRosterButtons.innerHTML = "";
  featuredTickets.forEach((item) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `quick-select-btn${
      appState.selectedHallTicket === item.htno ? " is-selected" : ""
    }`;
    btn.dataset.hallTicket = item.htno;
    btn.textContent = `${item.htno} (${item.note})`;
    btn.addEventListener("click", () => {
      dom.searchInput.value = item.htno;
      selectStudentByQuery(item.htno);
    });
    dom.quickRosterButtons.appendChild(btn);
  });
}

function renderStudentMarksheet(student) {
  if (!student) {
    dom.resultContainer.hidden = true;
    dom.emptyState.hidden = false;
    return;
  }

  dom.emptyState.hidden = true;
  dom.resultContainer.hidden = false;

  // KPI Summary Strip
  dom.kpiSgpa.textContent = student.sgpa.toFixed(2);
  dom.kpiSgpaMeta.textContent = `${student.semesterWeightedPoints} pts / ${student.semesterRegisteredCredits} credits`;

  dom.kpiCgpa.textContent = student.cgpa.toFixed(2);
  dom.kpiCgpaMeta.textContent = `Cumulative across ${student.previousCredits + student.semesterRegisteredCredits} credits`;

  dom.kpiCredits.textContent = `${student.semesterEarnedCredits} / ${student.semesterRegisteredCredits}`;
  dom.kpiCreditsMeta.textContent =
    student.backlogCount === 0
      ? "All 6 subjects cleared"
      : `${student.backlogCount} subject backlog`;

  dom.kpiStanding.textContent = student.classification;
  dom.kpiStandingMeta.textContent = student.passedAll
    ? "Eligible for regular promotion"
    : "Supplementary exam required";

  // Official Marksheet Header & Candidate Metadata
  dom.sheetHtno.textContent = student.hallTicket;
  dom.sheetName.textContent = student.name;
  dom.sheetBranch.textContent =
    BRANCH_FULL_NAMES[student.branch] || student.branch;
  dom.sheetSemester.textContent = student.semester;
  dom.sheetBatch.textContent = student.batch;

  dom.sheetOverallStatus.textContent = student.passedAll
    ? "PASS"
    : `FAIL (${student.backlogCount} Backlog${student.backlogCount > 1 ? "s" : ""})`;
  dom.sheetOverallStatus.className = `field-value status-text ${
    student.passedAll ? "is-pass" : "is-fail"
  }`;

  // Subject Table Rows
  dom.sheetSubjectsTbody.innerHTML = "";
  student.subjects.forEach((sub) => {
    const tr = document.createElement("tr");
    if (!sub.passed) {
      tr.classList.add("row-is-fail");
    }

    const displayName =
      sub.name === "Operating Systems" ? "Operating Systems (OS)" : sub.name;

    tr.innerHTML = `
      <td class="mono tabular-nums">${sub.code}</td>
      <td>${displayName}</td>
      <td class="num">${sub.credits}</td>
      <td class="num">${sub.internal}</td>
      <td class="num">${sub.external}</td>
      <td class="num">${sub.totalMarks}</td>
      <td class="num">${sub.gradePoint}</td>
      <td class="center grade-cell">${sub.grade}</td>
      <td class="center">
        <span class="status-text ${sub.passed ? "is-pass" : "is-fail"}">
          ${sub.passed ? "PASS" : "FAIL"}
        </span>
      </td>
    `;
    dom.sheetSubjectsTbody.appendChild(tr);
  });

  // Subject Table Footer Totals
  dom.sheetSubjectsTfoot.innerHTML = `
    <tr>
      <td colspan="2">Semester Totals (${student.subjects.length} Courses)</td>
      <td class="num">${student.semesterRegisteredCredits}</td>
      <td class="num">—</td>
      <td class="num">—</td>
      <td class="num">${student.totalMarksSum} / 600</td>
      <td class="num">${student.semesterWeightedPoints} pts</td>
      <td class="center">—</td>
      <td class="center">${student.passedAll ? "ALL CLEAR" : "BACKLOG"}</td>
    </tr>
  `;

  dom.sheetFormulaLine.textContent = `SGPA = ${student.semesterWeightedPoints} / ${student.semesterRegisteredCredits} = ${student.sgpa.toFixed(
    2
  )}`;
  dom.sheetSgpa.textContent = student.sgpa.toFixed(2);
  dom.sheetCgpa.textContent = student.cgpa.toFixed(2);
  dom.sheetClassification.textContent = student.classification;

  renderQuickRoster();
}

function selectStudentByQuery(rawQuery) {
  const query = rawQuery.trim().toUpperCase();
  if (!query) {
    dom.emptyStateMsg.textContent =
      "Enter a hall ticket number (such as 22CSE104) or a student name to inspect their grade sheet.";
    renderStudentMarksheet(null);
    return;
  }

  let match = STUDENT_INDEX.get(query);
  if (!match) {
    match = PROCESSED_STUDENTS.find(
      (s) =>
        s.hallTicket.toUpperCase().includes(query) ||
        s.name.toUpperCase().includes(query)
    );
  }

  if (match) {
    appState.selectedHallTicket = match.hallTicket;
    renderStudentMarksheet(match);
  } else {
    appState.selectedHallTicket = "";
    dom.emptyStateMsg.textContent = `No student record matched "${rawQuery.trim()}". Try 22CSE104, 22CSE101, or 22ECE201.`;
    renderStudentMarksheet(null);
    renderQuickRoster();
  }
}

// 9. Rendering: Pre-Computed Batch Analytics & Chart.js Visualizations
function renderBatchOverview() {
  const stats = BATCH_ANALYTICS;

  dom.batchTotalStudents.textContent = `${stats.totalStudents} Students`;
  dom.batchBranchSplit.textContent = `CSE: ${stats.branchCounts.CSE} · ECE: ${stats.branchCounts.ECE}`;

  dom.batchPassRate.textContent = `${stats.overallPassRate.toFixed(1)}%`;
  dom.batchPassCount.textContent = `${stats.allClearCount} of ${stats.totalStudents} cleared all 6 courses`;

  dom.batchMeanCgpa.textContent = stats.meanCgpa.toFixed(2);
  dom.batchDistinctionCount.textContent = `${stats.distinctionCount} Distinction achievers`;

  dom.batchLowestSubject.textContent = `${stats.lowestPassSubject.name} · ${stats.lowestPassSubject.passRate.toFixed(
    0
  )}%`;
  dom.batchLowestSubjectMeta.textContent = `${stats.lowestPassSubject.passCount} Pass · ${stats.lowestPassSubject.failCount} Fail (${stats.lowestPassSubject.failRate.toFixed(
    0
  )}% fail rate)`;

  // Render clean numerical summary below Subject Pass-Rate Chart
  dom.subjectRateSummary.innerHTML = "";
  stats.subjectStats.forEach((sub) => {
    const isLowest = sub.code === stats.lowestPassSubject.code;
    const item = document.createElement("div");
    item.className = "stat-pair";
    item.innerHTML = `
      <span class="stat-pair-label">${sub.name}</span>
      <span class="stat-pair-value ${isLowest ? "is-alert" : ""}">
        ${sub.passRate.toFixed(0)}% Pass (${sub.passCount}/${sub.totalCount})
      </span>
    `;
    dom.subjectRateSummary.appendChild(item);
  });

  // Render clean numerical summary below CGPA Histogram
  dom.cgpaBinSummary.innerHTML = "";
  stats.cgpaBins.forEach((bin) => {
    const item = document.createElement("div");
    item.className = "stat-pair";
    item.innerHTML = `
      <span class="stat-pair-label">CGPA ${bin.label}</span>
      <span class="stat-pair-value">${bin.count} student${
      bin.count === 1 ? "" : "s"
    }</span>
    `;
    dom.cgpaBinSummary.appendChild(item);
  });
}

function renderAnalyticsCharts() {
  if (typeof window.Chart === "undefined") {
    return;
  }

  const stats = BATCH_ANALYTICS;
  const passCanvas = document.getElementById("subject-passrate-chart");
  const cgpaCanvas = document.getElementById("cgpa-distribution-chart");
  if (!passCanvas || !cgpaCanvas) return;

  if (appState.passRateChartInstance) {
    appState.passRateChartInstance.destroy();
  }
  if (appState.cgpaChartInstance) {
    appState.cgpaChartInstance.destroy();
  }

  const lowestCode = stats.lowestPassSubject.code;

  // Chart 1: Subject Pass & Fail Rates (Bar Chart)
  appState.passRateChartInstance = new window.Chart(passCanvas, {
    type: "bar",
    data: {
      labels: stats.subjectStats.map((s) =>
        s.name === "Operating Systems" ? "Operating Systems" : s.name
      ),
      datasets: [
        {
          label: "Pass Rate (%)",
          data: stats.subjectStats.map((s) => s.passRate),
          backgroundColor: stats.subjectStats.map((s) =>
            s.code === lowestCode ? "#B91C1C" : "#1D4ED8"
          ),
          borderRadius: 4,
          barPercentage: 0.72,
        },
        {
          label: "Fail Rate (%)",
          data: stats.subjectStats.map((s) => s.failRate),
          backgroundColor: "#E2E8F0",
          borderRadius: 4,
          barPercentage: 0.72,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: "top",
          align: "end",
          labels: {
            boxWidth: 12,
            usePointStyle: false,
            font: { family: "DM Sans", size: 12, weight: "600" },
            color: "#334155",
          },
        },
        tooltip: {
          callbacks: {
            label(context) {
              const sub = stats.subjectStats[context.dataIndex];
              if (context.datasetIndex === 0) {
                return `Pass: ${sub.passRate}% (${sub.passCount}/${sub.totalCount} students)`;
              }
              return `Fail: ${sub.failRate}% (${sub.failCount}/${sub.totalCount} students)`;
            },
          },
        },
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            color: "#334155",
            font: { family: "DM Sans", size: 11, weight: "600" },
          },
        },
        y: {
          min: 0,
          max: 100,
          grid: { color: "#F1F5F9" },
          ticks: {
            stepSize: 20,
            color: "#64748B",
            font: { family: "JetBrains Mono", size: 11 },
            callback: (val) => `${val}%`,
          },
        },
      },
    },
  });

  // Chart 2: CGPA Distribution Histogram + Bell Curve Overlay
  appState.cgpaChartInstance = new window.Chart(cgpaCanvas, {
    type: "bar",
    data: {
      labels: stats.cgpaBins.map((b) => b.label),
      datasets: [
        {
          type: "line",
          label: "Cohort Curve",
          data: stats.cgpaBins.map((b) => b.count),
          borderColor: "#0F172A",
          borderWidth: 2,
          pointBackgroundColor: "#0F172A",
          pointRadius: 3.5,
          tension: 0.38,
          fill: false,
        },
        {
          type: "bar",
          label: "Students in Band",
          data: stats.cgpaBins.map((b) => b.count),
          backgroundColor: "#3B82F6",
          borderRadius: 4,
          barPercentage: 0.68,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: "top",
          align: "end",
          labels: {
            boxWidth: 12,
            font: { family: "DM Sans", size: 12, weight: "600" },
            color: "#334155",
          },
        },
        tooltip: {
          callbacks: {
            label(context) {
              return `${context.dataset.label}: ${context.parsed.y} students`;
            },
          },
        },
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: {
            color: "#334155",
            font: { family: "JetBrains Mono", size: 11 },
          },
        },
        y: {
          beginAtZero: true,
          suggestedMax: 10,
          grid: { color: "#F1F5F9" },
          ticks: {
            stepSize: 2,
            color: "#64748B",
            font: { family: "JetBrains Mono", size: 11 },
          },
        },
      },
    },
  });

  appState.chartsInitialized = true;
}

function renderLeaderboard(branchKey) {
  appState.leaderboardBranch = branchKey;

  dom.branchFilterButtons.forEach((btn) => {
    btn.classList.toggle("is-active", btn.dataset.branch === branchKey);
  });

  const toppers = BATCH_ANALYTICS.leaderboardsByBranch[branchKey] || [];
  dom.leaderboardTbody.innerHTML = "";

  toppers.forEach((student, index) => {
    const rank = index + 1;
    const tr = document.createElement("tr");
    tr.className = "leaderboard-row";
    tr.tabIndex = 0;
    tr.setAttribute(
      "aria-label",
      `Open marksheet for ${student.name}, Hall Ticket ${student.hallTicket}`
    );

    let rankMarkup = `<span class="tabular-nums">#${rank}</span>`;
    if (rank === 1) {
      rankMarkup = `<span class="medal-badge medal-gold">Gold · #1</span>`;
    } else if (rank === 2) {
      rankMarkup = `<span class="medal-badge medal-silver">Silver · #2</span>`;
    } else if (rank === 3) {
      rankMarkup = `<span class="medal-badge medal-bronze">Bronze · #3</span>`;
    }

    tr.innerHTML = `
      <td class="rank-cell">${rankMarkup}</td>
      <td class="mono tabular-nums">${student.hallTicket}</td>
      <td><strong>${student.name}</strong></td>
      <td>${student.branch}</td>
      <td class="num">${student.semesterEarnedCredits} / ${student.semesterRegisteredCredits}</td>
      <td class="num"><strong>${student.sgpa.toFixed(2)}</strong></td>
      <td class="num">${student.cgpa.toFixed(2)}</td>
      <td>
        <span class="status-text ${student.passedAll ? "is-pass" : "is-fail"}">
          ${student.classification}
        </span>
      </td>
    `;

    const openStudentMarksheet = () => {
      dom.searchInput.value = student.hallTicket;
      selectStudentByQuery(student.hallTicket);
      switchTab("marksheet");
      window.scrollTo({ top: 0, behavior: "smooth" });
    };

    tr.addEventListener("click", openStudentMarksheet);
    tr.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openStudentMarksheet();
      }
    });

    dom.leaderboardTbody.appendChild(tr);
  });
}

// 10. Tab Navigation & Event Wiring
function switchTab(targetTab) {
  appState.activeTab = targetTab;
  const isMarksheet = targetTab === "marksheet";

  dom.tabButtons.forEach((btn) => {
    const active = btn.dataset.tab === targetTab;
    btn.classList.toggle("is-active", active);
    btn.setAttribute("aria-selected", String(active));
  });

  dom.panelMarksheet.hidden = !isMarksheet;
  dom.panelMarksheet.classList.toggle("is-active", isMarksheet);

  dom.panelAnalytics.hidden = isMarksheet;
  dom.panelAnalytics.classList.toggle("is-active", !isMarksheet);

  if (!isMarksheet) {
    // Render Chart.js visualizations once visible so canvas dimensions calculate cleanly
    requestAnimationFrame(() => {
      renderAnalyticsCharts();
    });
  }
}

function initApp() {
  // Initial Marksheet Render (Default: 22CSE104 with SGPA 8.85)
  selectStudentByQuery("22CSE104");

  // Pre-computed Batch Analytics & Leaderboard Render
  renderBatchOverview();
  renderLeaderboard("ALL");

  // Tab Switch Listeners
  dom.tabButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      switchTab(btn.dataset.tab);
    });
  });

  // Search Input & Form Listeners
  dom.lookupForm.addEventListener("submit", (event) => {
    event.preventDefault();
    selectStudentByQuery(dom.searchInput.value);
  });

  dom.searchInput.addEventListener("input", (event) => {
    const val = event.target.value.trim();
    if (val.length >= 3) {
      selectStudentByQuery(val);
    }
  });

  dom.clearSearchBtn.addEventListener("click", () => {
    dom.searchInput.value = "";
    dom.searchInput.focus();
  });

  dom.resetDefaultBtn.addEventListener("click", () => {
    dom.searchInput.value = "22CSE104";
    selectStudentByQuery("22CSE104");
  });

  // Branch Leaderboard Filter Listeners
  dom.branchFilterButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      renderLeaderboard(btn.dataset.branch);
    });
  });

  // Print / PDF Marksheet Trigger
  dom.printBtn.addEventListener("click", () => {
    if (!appState.selectedHallTicket) {
      dom.searchInput.value = "22CSE104";
      selectStudentByQuery("22CSE104");
    }
    if (appState.activeTab !== "marksheet") {
      switchTab("marksheet");
    }
    window.print();
  });
}

document.addEventListener("DOMContentLoaded", initApp);
